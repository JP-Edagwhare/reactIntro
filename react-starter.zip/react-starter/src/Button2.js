import React from 'react'

export default class Button2 extends React.Component {
    render() {
        return <button>Sign Out</button>
    }

}