import React from 'react'

export default function UserProfile(props) {
    return (
        <div>
            <h2>{props.userInfo.name}</h2>
            <p>{props.userInfo.age + props.userInfo.yearValue}</p>
            <p>{props.userInfo.height + props.userInfo.heightValue}</p>
        </div>
    )
}
